# Practicas en Android Studio - Unidad II
Repositorio exclusivamente dirigido para subir proyectos hechos para dispositivos moviles

- Branch musica: Implementacion de [@Reproductor de musica](https://github.com/xPorotin9/AndroidStudio/tree/Musica)

-  Repositorio de practicas Kotlin (Unidad I)
https://github.com/xPorotin9/Moviles
## Authors

- [@José C. Machaca](https://www.github.com/xPorotin9)
